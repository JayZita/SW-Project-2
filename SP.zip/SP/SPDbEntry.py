class SPDbEntry:
  def __init__(self,
                id=1,
                name='Chracter Name',
                job='Swordsman',
                level='Level',
                status='Finding Quest'):
      self.id = id
      self.name = name
      self.level = level
      self.job = job
      self.status = status
